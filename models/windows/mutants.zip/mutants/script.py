import glob
import subprocess

separator = '================================================================================\n'

diag = ''
      
killing_report = dict()

mutants = glob.glob('*.pml')
survivors = glob.glob('*.pml')
assert(len(mutants) > 0)

for properties in glob.glob('../properties/*'):
	print(properties)
	killing_report[properties] = list()
	for mutant in mutants:
		print(separator)
		
		res = subprocess.run(['spin','-a', '-F', properties, mutant], capture_output=True)
		to_print = res.stdout.decode('utf-8')
		if to_print.find('error') != -1 or to_print.find('Error') != -1 or to_print.find('ERROR') != -1:
			print('syntax or semantic error ' + mutant+'#'+properties+'\n')
			continue
		print('parsed \t\t' + mutant+'#'+properties)
			
		res = subprocess.run(['gcc', '-o', 'pan', 'pan.c'], capture_output=True)
		to_print = res.stdout.decode('utf-8')
		if to_print.find('error') != -1:
			diag += 'compilation error ' + mutant+"#"+properties +'\n'
			continue
		print('compiled \t' + mutant + '#'+ properties)
		
		
		print('checking \t'+mutant+'#'+properties+'\n')
		try:
			res = subprocess.run(['./pan', '-a', '-m40000'], capture_output=True, timeout=10)
		except subprocess.TimeoutExpired:
			print('timeout \t'+mutant + '#'+ properties+'\n')
			diag += (properties+'\t\t'+ mutant +'\t\t timeout\n')
			killing_report[properties].append(mutant)
			if mutant in survivors:
				survivors.remove(mutant)
			continue
		
		to_print = res.stdout.decode('utf-8')
		diag += to_print+'\n'+separator
		
		if to_print.find('acceptance cycle') != -1 or to_print.find('assertion violated') != -1:
			print('violated \t'+mutant+'#'+properties+'\n')
			killing_report[properties].append(mutant)
			if mutant in survivors:
				survivors.remove(mutant)
			diag += (properties+'\t\t'+ mutant +'\t\t violated\n')
		else:
			print('satisfied \t'+mutant+'#'+properties+'\n')
			diag += (properties+'\t\t'+ mutant +'\t\t satisfied\n')
	diag += 'killed '+ str(len(killing_report[properties]) * 100 / len(mutants)) + '% of mutants\n\n'
diag += 'TOTAL : '+ str(len(survivors) * 100 / len(mutants)) + '%\n'
diag += 'SURVIVORS :'

for survivor in survivors:
	diag += str(survivor) + '\n'

print(diag)
log = fopen("log.txt", 'w')
log.write(diag)

subprocess.run(['rm', '-f', '*.tmp'])
subprocess.run(['rm', '-f', '*trail'])
subprocess.run(['rm', '-f', './pan.*'])


