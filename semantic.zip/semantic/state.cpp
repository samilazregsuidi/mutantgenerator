#include "state.hpp"
#include "payload.hpp"
#include "process.hpp"
#include "symbols.hpp"
#include "ast.hpp"
#include "payload.hpp"
#include "state.hpp"
#include "transition.hpp"
#include "process.hpp"
#include "automata.hpp"

state::state(const symTable* symTab, const fsm* st)
    : pl(new payLoad())
    , pidCounter(0)
{
    this->visitTab(symTab);
}

void state::visitTab(const symTable* symTab){
    assert(symTab->isGlobal());

    for(auto s: symTab->getSymbols()) {
        s->acceptVisitor(this);
    }
}

void state::visitNA(const naSymNode* sym){
    sym = sym; assert(false);
}

void state::visitBit(const bitSymNode* sym){
    pl->addVariable(nameSpace.top()+"."+sym->getName(), sym);
}

void state::visitBool(const boolSymNode* sym){
    pl->addVariable(nameSpace.top()+"."+sym->getName(), sym);
}

void state::visitByte(const byteSymNode* sym){
    pl->addVariable(nameSpace.top()+"."+sym->getName(), sym);
}

void state::visitShort(const shortSymNode* sym){
    pl->addVariable(nameSpace.top()+"."+sym->getName(), sym);
}

void state::visitInt(const intSymNode* sym){
    pl->addVariable(nameSpace.top()+"."+sym->getName(), sym);
}

void state::visitUnsgn(const unsgnSymNode* sym){
    sym = sym; assert(false);
}

void state::visitMtype(const mtypeSymNode* sym){
    pl->addVariable(nameSpace.top()+"."+sym->getName(), sym);
}

void state::visitChan(const chanSymNode* sym){
    pl->addVariable(nameSpace.top()+"."+sym->getName(), sym);
}

void state::visitCid(const cidSymNode* sym){
    pl->addVariable(nameSpace.top()+"."+sym->getName(), sym);
}

void state::visitPid(const pidSymNode* sym){
    pl->addVariable(nameSpace.top()+"."+sym->getName(), sym);
}

void state::visitTdef(const tdefSymNode* sym){
    sym = sym;
}

void state::visitProc(const procSymNode* sym){
    int actives = sym->getActiveExpr()->getCstValue();
    for(int i = 0; i < actives; ++i) {
        nameSpace.push(sym->getName() + "[" + std::to_string(i) + "]");

        auto init = sm->getInitNodes()[sym->getName()];
        auto proc = new process(this, nameSpace.top(), init, sym, pidCounter++);
        procs.push_back(proc);   

        for(auto s: sym->getBlock()->getLocalSymTab()->getSymbols())
            s->acceptVisitor(this);

        nameSpace.pop();
    }

}

void state::visitUtype(const utypeSymNode* sym){
    for(auto s: sym->getUType()->getFields()) {
        nameSpace.push(nameSpace.top() + sym->getUType()->getName());
        s->acceptVisitor(this);
    }
    nameSpace.pop();
}

void state::visitNever(const neverSymNode* sym){
    nameSpace.push(sym->getName());

    auto init = sm->getInitNodes()[sym->getName()];
    auto proc = new process(this, nameSpace.top(), init, sym, pidCounter++);
    procs.push_back(proc);  

    for(auto s: sym->getBlock()->getLocalSymTab()->getSymbols())
        s->acceptVisitor(this);
    nameSpace.pop();
}

void state::visitInit(const initSymNode* sym){
    nameSpace.push(sym->getName());

    auto init = sm->getInitNodes()[sym->getName()];
    auto proc = new process(this, nameSpace.top(), init, sym, pidCounter++);
    procs.push_back(proc);  

    for(auto s: sym->getBlock()->getLocalSymTab()->getSymbols())
        s->acceptVisitor(this);
    nameSpace.pop();
}

void state::visitMtypedef(const mtypedefSymNode* sym){
    sym = sym;
}

void state::visitCmtype(const cmtypeSymNode* sym){
    sym = sym;
}

void state::visitInline(const inlineSymNode* sym){
    sym = sym;
}

/**************************************************************************************/

std::list<transition*> state::getTransitions(void) const {

    std::list<transition*> allTrans;

    for(auto p: procs) {
        
        std::list<transition*> procTrans;
        
        const fsmNode* procLoc = p->getLocation();
        if(!procLoc || (exclusivePid != -1 && exclusivePid != p->getPid() && handshake == false))
            continue;

        for(auto e: p->getNextFSMEdges()) {

            
            e->getExpression()->acceptVisitor(eval);
            if(/*eval->last()*/true){
                
                procTrans.push_back(new transition(p, e, e->getProbability()));
            }
        }

        double totalProc = 0;
        for(auto t: procTrans) {
            totalProc += t->getProbability();
        }

        for(auto t: procTrans) {
            t->setProbability(t->getProbability()/totalProc);
        }

        allTrans.merge(procTrans);

    }

    for(auto t: allTrans)
        t->setProbability(t->getProbability()/procs.size());

    return allTrans;
}

state* state::fireTransition(transition* trans) {

    /*apply->copy(this);*/

    trans->getFSMEdge()->getExpression()->acceptVisitor(apply);

    if(trans->getResponse())
        trans->getResponse()->getFSMEdge()->getExpression()->acceptVisitor(apply);

    if(trans->getNeverTransition())
        trans->getNeverTransition()->getFSMEdge()->getExpression()->acceptVisitor(apply);

    /*apply->returnState()*/

}