#ifndef PAYLOAD_H
#define PAYLOAD_H

#include <vector>
#include <map>

class symTable;
class symbol;

class payLoad {
public:

    unsigned int channelLen(const std::string& id, const symbol* sym);

    void addVariable(const std::string& id, const symbol* sym);

    template <typename T> void setValue(const std::string& id, const T& value);
    template <typename T> T getValue(const std::string& id) const;

    const std::map<const std::string&, unsigned int>& getOffsetMap(void) const;
    const std::map<const std::string&, void*>& getPlayLoadMap(void) const;

    symTable* getSymTab(void) const;
    void* getRawPayload(void) const;
private:
    symTable* symTab;
    void* rawPayLoad;
    std::map<const std::string&, unsigned int> offsetMap;
    std::map<const std::string&, void*> payloadMap;
};

#endif