#ifndef PROCESS_H
#define PROCESS_H

#include <vector>
#include <string>

class symbol;

class fsmNode;
class fsmEdge;

class state;
class payload;

class process {
public:
    process(state* s, const std::string& name, const fsmNode* location, const symbol* procType, const int pid);

    const fsmNode* getLocation(void) const;
    std::vector<const fsmNode*> getNextLocations(void) const;
    std::vector<const fsmEdge*> getNextFSMEdges(void) const;
    void applyFsmEdge(const fsmEdge* edge);

    int getPid(void) const;
    const std::string& getName(void) const;
    const symbol* getProcType(void) const; 
private:
    state* s;
    std::string name;
    const fsmNode* location;
    const int pid;
};

#endif