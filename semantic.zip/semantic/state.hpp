#ifndef STATE_H
#define STATE_H

#include <list>
#include <map>
#include <stack>

#include "symbols.hpp"

class fsm;
class symTable;
class symbol;

class transition;
class process;

class payLoad;

class state : public symTabConstVisitor{
public:
    state(const symTable* ast, const fsm* st);
    
    std::list<transition*> getTransitions(void) const;
    state* fireTransition(transition* trans);
    state* fireTransition(unsigned int id);

    std::list<process*> getExecutableProcesses(void) const;

    std::list<state*> getSuccStates(void) const;

    payLoad* getPayload(void) const;

    const std::list<process*>& getProcesses(void) const;

	

private:
    void visitTab(const symTable* tab) override;
	void visitNA(const naSymNode* sym) override;
	void visitBit(const bitSymNode* sym) override ;
	void visitBool(const boolSymNode* sym) override;
	void visitByte(const byteSymNode* sym) override;
	void visitShort(const shortSymNode* sym) override;
	void visitInt(const intSymNode* sym) override;
	void visitUnsgn(const unsgnSymNode* sym) override;
	void visitMtype(const mtypeSymNode* sym) override;
	void visitChan(const chanSymNode* sym) override;
	void visitCid(const cidSymNode* sym) override;
	void visitPid(const pidSymNode* sym) override;
	void visitTdef(const tdefSymNode* sym) override;
	void visitProc(const procSymNode* sym) override;
	void visitUtype(const utypeSymNode* sym) override;
	void visitNever(const neverSymNode* sym) override;
	void visitInit(const initSymNode* sym) override;
	void visitMtypedef(const mtypedefSymNode* sym) override;
	void visitCmtype(const cmtypeSymNode* sym) override;
	void visitInline(const inlineSymNode* sym) override;



private:
    const symTable* symTab;
    const fsm* sm;
    std::stack<std::string> nameSpace;
    int pidCounter;
    int exclusivePid;
    bool handshake;

    payLoad* pl;
	std::vector<process*> procs;

    ASTConstVisitor* eval;
    ASTConstVisitor* apply;
};

#endif