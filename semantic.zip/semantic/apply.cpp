#include "apply.hpp"

int apply::visit(const stmnt* node) {
}
int apply::visit(const stmntChanRecv* node) {
}
int apply::visit(const stmntChanSnd* node) {
}
int apply::visit(const stmntOpt* node) {
}
int apply::visit(const stmntIf* node) {
}
int apply::visit(const stmntDo* node) {
}
int apply::visit(const stmntBreak* node) {
}
int apply::visit(const stmntGoto* node) {
}
int apply::visit(const stmntLabel* node) {
}
int apply::visit(const stmntSeq* node) {
}
int apply::visit(const stmntFct* node) {
}
int apply::visit(const stmntAtomic* node) {
}
int apply::visit(const stmntDStep* node) {
}
int apply::visit(const stmntAsgn* node) {
}
int apply::visit(const stmntIncr* node) {
}
int apply::visit(const stmntDecr* node) {
}
int apply::visit(const stmntPrint* node) {
}
int apply::visit(const stmntPrintm* node) {
}
int apply::visit(const stmntAssert* node) {
}
int apply::visit(const stmntExpr* node) {
}
int apply::visit(const stmntElse* node) {
}
int apply::visit(const stmntWait* node) {
}
int apply::visit(const stmntWhen* node) {
}
int apply::visit(const varDecl* node) {
}
int apply::visit(const chanDecl* node) {
}
int apply::visit(const tdefDecl* node) {
}
int apply::visit(const mtypeDecl* node) {
}
int apply::visit(const inlineDecl* node) {
}
int apply::visit(const procDecl* node) {
}
int apply::visit(const initDecl* node) {
}
int apply::visit(const expr* node) {
}
int apply::visit(const exprCond* node) {
}
int apply::visit(const exprRArg* node) {
}
int apply::visit(const exprRArgVar* node) {
}
int apply::visit(const exprRArgEval* node) {
}
int apply::visit(const exprRArgConst* node) {
}
int apply::visit(const exprArgList* node) {
}
int apply::visit(const exprRun* node) {
}
int apply::visit(const exprConst* node) {
}
int apply::visit(const exprTimeout* node) {
}
int apply::visit(const exprSkip* node) {
}
int apply::visit(const exprTrue* node) {
}
int apply::visit(const exprFalse* node) {
}
int apply::visit(const exprPlus* node) {
}
int apply::visit(const exprMinus* node) {
}
int apply::visit(const exprTimes* node) {
}
int apply::visit(const exprDiv* node) {
}
int apply::visit(const exprMod* node) {
}
int apply::visit(const exprGT* node) {
}
int apply::visit(const exprLT* node) {
}
int apply::visit(const exprGE* node) {
}
int apply::visit(const exprLE* node) {
}
int apply::visit(const exprEQ* node) {
}
int apply::visit(const exprNE* node) {
}
int apply::visit(const exprAnd* node) {
}
int apply::visit(const exprOr* node) {
}
int apply::visit(const exprBitwAnd* node) {
}
int apply::visit(const exprBitwOr* node) {
}
int apply::visit(const exprBitwXor* node) {
}
int apply::visit(const exprLShift* node) {
}
int apply::visit(const exprRShift* node) {
}
int apply::visit(const exprPar* node) {
}
int apply::visit(const exprCount* node) {
}
int apply::visit(const exprUMin* node) {
}
int apply::visit(const exprNeg* node) {
}
int apply::visit(const exprBitwNeg* node) {
}
int apply::visit(const exprLen* node) {
}
int apply::visit(const exprFull* node) {
}
int apply::visit(const exprNFull* node) {
}
int apply::visit(const exprEmpty* node) {
}
int apply::visit(const exprNEmpty* node) {
}
