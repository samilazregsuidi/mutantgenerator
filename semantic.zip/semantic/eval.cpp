#include "eval.hpp"
#include "ast.hpp"
#include "process.hpp"

int eval::visit(const stmnt* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const stmntChanRecv* node) {
}
int eval::visit(const stmntChanSnd* node) {
}
int eval::visit(const stmntOpt* node) {
	return 1;
}
int eval::visit(const stmntIf* node) {
	return 1;
}
int eval::visit(const stmntDo* node) {
	return 1;
}
int eval::visit(const stmntBreak* node) {
	return 1;
}
int eval::visit(const stmntGoto* node) {
	return 1;
}
int eval::visit(const stmntLabel* node) {
	return 1;
}
int eval::visit(const stmntSeq* node) {
	return 1;
}
int eval::visit(const stmntFct* node) {
	node = node; assert(false); return -1;
}
int eval::visit(const stmntAtomic* node) {
	node = node; assert(false); return -1;
}
int eval::visit(const stmntDStep* node) {
	node = node; assert(false); return -1; 
}
int eval::visit(const stmntAsgn* node) {
	return 1;
}
int eval::visit(const stmntIncr* node) {
	return node->acceptVisitor(this) + 1;
}
int eval::visit(const stmntDecr* node) {
	return node->acceptVisitor(this) - 1;
}
int eval::visit(const stmntPrint* node) {
	return 1;
}
int eval::visit(const stmntPrintm* node) {
	return 1;
}
int eval::visit(const stmntAssert* node) {
	return 1;
}
int eval::visit(const stmntExpr* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const stmntElse* node) {
	return 1;
}
int eval::visit(const stmntWait* node) {
	node = node; assert(false); return -1;
}
int eval::visit(const stmntWhen* node) {
	node = node; assert(false); return -1;
}
int eval::visit(const varDecl* node) {
	return 1;
}
int eval::visit(const chanDecl* node) {
	return 1;
}
int eval::visit(const tdefDecl* node) {
	return 1;
}
int eval::visit(const mtypeDecl* node) {
	return 1;
}
int eval::visit(const inlineDecl* node) {
	return 1;
}
int eval::visit(const procDecl* node) {
	return 1;
}
int eval::visit(const initDecl* node) {
	return 1;
}
int eval::visit(const expr* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprCond* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprRArg* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprRArgVar* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprRArgEval* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprRArgConst* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprArgList* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprRun* node) {
	return 1;
}
int eval::visit(const exprConst* node) {
	return node->getCstValue();
}
int eval::visit(const exprTimeout* node) {
	return 1;
}
int eval::visit(const exprSkip* node) {
	return 1;
}
int eval::visit(const exprTrue* node) {
	return 1;
}
int eval::visit(const exprFalse* node) {
	return 0;
}
int eval::visit(const exprPlus* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprMinus* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprTimes* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprDiv* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprMod* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprGT* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprLT* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprGE* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprLE* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprEQ* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprNE* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprAnd* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprOr* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprBitwAnd* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprBitwOr* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprBitwXor* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprLShift* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprRShift* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprPar* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprCount* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprUMin* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprNeg* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprBitwNeg* node) {
	return node->acceptVisitor(this);
}
int eval::visit(const exprLen* node) {
	return payload->len(proc->getName(), node->getVarRef());
}
int eval::visit(const exprFull* node) {
}

int eval::visit(const exprNFull* node) {
}
int eval::visit(const exprEmpty* node) {
}
int eval::visit(const exprNEmpty* node) {
}