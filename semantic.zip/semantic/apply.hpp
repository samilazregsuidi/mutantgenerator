#ifndef APPLY_H
#define APPLY_H

#include "astVisitor.hpp"

class apply: public ASTConstVisitorInt {
public:
	int visit(const stmnt* node) override;
	int visit(const stmntChanRecv* node) override;
	int visit(const stmntChanSnd* node) override;
	int visit(const stmntOpt* node) override;
	int visit(const stmntIf* node) override;
	int visit(const stmntDo* node) override;
	int visit(const stmntBreak* node) override;
	int visit(const stmntGoto* node) override;
	int visit(const stmntLabel* node) override;
	int visit(const stmntSeq* node) override;
	int visit(const stmntFct* node) override;
	int visit(const stmntAtomic* node) override;
	int visit(const stmntDStep* node) override;
	int visit(const stmntAsgn* node) override;
	int visit(const stmntIncr* node) override;
	int visit(const stmntDecr* node) override;
	int visit(const stmntPrint* node) override;
	int visit(const stmntPrintm* node) override;
	int visit(const stmntAssert* node) override;
	int visit(const stmntExpr* node) override;
	int visit(const stmntElse* node) override;
	int visit(const stmntWait* node) override;
	int visit(const stmntWhen* node) override;
	int visit(const varDecl* node) override;
	int visit(const chanDecl* node) override;
	int visit(const tdefDecl* node) override;
	int visit(const mtypeDecl* node) override;
	int visit(const inlineDecl* node) override;
	int visit(const procDecl* node) override;
	int visit(const initDecl* node) override;
	int visit(const expr* node) override;
	int visit(const exprCond* node) override;
	int visit(const exprRArg* node) override;
	int visit(const exprRArgVar* node) override;
	int visit(const exprRArgEval* node) override;
	int visit(const exprRArgConst* node) override;
	int visit(const exprArgList* node) override;
	int visit(const exprRun* node) override;
	int visit(const exprConst* node) override;
	int visit(const exprTimeout* node) override;
	int visit(const exprSkip* node) override;
	int visit(const exprTrue* node) override;
	int visit(const exprFalse* node) override;
	int visit(const exprPlus* node) override;
	int visit(const exprMinus* node) override;
	int visit(const exprTimes* node) override;
	int visit(const exprDiv* node) override;
	int visit(const exprMod* node) override;
	int visit(const exprGT* node) override;
	int visit(const exprLT* node) override;
	int visit(const exprGE* node) override;
	int visit(const exprLE* node) override;
	int visit(const exprEQ* node) override;
	int visit(const exprNE* node) override;
	int visit(const exprAnd* node) override;
	int visit(const exprOr* node) override;
	int visit(const exprBitwAnd* node) override;
	int visit(const exprBitwOr* node) override;
	int visit(const exprBitwXor* node) override;
	int visit(const exprLShift* node) override;
	int visit(const exprRShift* node) override;
	int visit(const exprPar* node) override;
	int visit(const exprCount* node) override;
	int visit(const exprUMin* node) override;
	int visit(const exprNeg* node) override;
	int visit(const exprBitwNeg* node) override;
	int visit(const exprLen* node) override;
	int visit(const exprFull* node) override;
	int visit(const exprNFull* node) override;
	int visit(const exprEmpty* node) override;
	int visit(const exprNEmpty* node) override;
	
};

#endif
