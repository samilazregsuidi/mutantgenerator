#ifndef TRANSITION_H
#define TRANSITION_H

class fsmEdge;
class state;
class process;

class transition {
public:
    transition(process* p, const fsmEdge* e, double prob, transition* response = nullptr);
    state* execute(void) const;
    state* getOriginState(void) const;
    double getProbability(void) const;
    void setProbability(double newProb);
    const fsmEdge* getFSMEdge(void) const;
    transition* getResponse(void) const;
    transition* getNeverTransition(void) const;

private:
    process* proc;
    const fsmEdge* edge;
    double prob;
    transition* response;
    transition* never;
};

#endif